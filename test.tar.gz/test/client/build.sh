aclocal
autoconf
automake --add-missing

pwd=$(pwd)
./configure --prefix=$pwd/build
make
make install

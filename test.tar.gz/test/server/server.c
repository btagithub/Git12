#include<stdio.h>
#include"rpc_test.h"

int *
printmessage_1_svc(msg, req)
	char **msg;	
	struct svc_req *req;		/* details of call */
{
	static int result;			/* must be static! */
	FILE *f;
 
	printf("%s\r\n", *msg);
	result = 1;
	return (&result);
}
